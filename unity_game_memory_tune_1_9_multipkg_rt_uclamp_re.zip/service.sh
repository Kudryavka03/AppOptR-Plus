#!/system/bin/sh
# Low-overhead KernelSU/Magisk service for Unity loading memory pressure tests.
# The service script starts one background daemon and exits, so KernelSU's
# service event is not blocked. It avoids /proc-wide scans and never calls tr.

PKGS="com.bilibili.star.bili com.bilibili.star.bilinogc net.gamon.bdTW jp.co.craftegg.band com.bilibili.sirius.official"
GLOBAL_SWAPPINESS=30
GAME_SWAPPINESS=0
WATERMARK_SCALE_FACTOR=80
VFS_CACHE_PRESSURE=80
PROTECT_MEMCG="/dev/memcg/protect_memcg_3"
LOG="/data/local/tmp/unity_game_memory_tune_magisk.log"
PIDFILE="/data/local/tmp/unity_game_memory_tune.pid"
STATE_DIR="/data/local/tmp/unity_game_memory_tune_state"
LOOP_SECONDS=10
# One thread name per line. Add future Unity threads here without changing
# the detection logic. A word list is used instead of Bash-only arrays so the
# module remains compatible with Android /system/bin/sh and BusyBox ash.
RT_THREAD_NAMES="
Loading.AsyncRe1
"
UCLAMP_THREAD_NAMES="
AssetGarbageCol
BatchDeleteObje
Loading.AsyncRe
Loading.Preload
"
RENICE_THREAD_NAMES="
UnityGfxDeviceW
UnityMain
"
# SCHED_FIFO priority 1 is already above every normal CFS thread while
# minimizing the risk of starving critical system work.
UNITY_RT_PRIORITY=1
UNITY_UCLAMP_MIN=1024
UNITY_NICE=-20

log() {
  echo "$(date '+%F %T') $*" #>> "$LOG"
}

write_file() {
  local path="$1"
  local value="$2"
  [ -e "$path" ] || return 0
  echo "$value" > "$path" 2>/dev/null && log "set $path=$value"
}

pid_uid() {
  awk '/^Uid:/{print $2; exit}' "/proc/$1/status" 2>/dev/null
}

pid_memcg() {
  awk -F: '$2=="memory"{print "/dev/memcg" $3; exit}' "/proc/$1/cgroup" 2>/dev/null
}

prepare_protect_memcg() {
  [ -d "$PROTECT_MEMCG" ] || return 1
  echo "$GAME_SWAPPINESS" > "$PROTECT_MEMCG/memory.swappiness" 2>/dev/null
  echo 1 > "$PROTECT_MEMCG/memory.move_charge_at_immigrate" 2>/dev/null
  return 0
}

apply_global_tuning() {
  echo 0
  #write_file /proc/sys/vm/swappiness "$GLOBAL_SWAPPINESS"
  #write_file /proc/sys/vm/watermark_scale_factor "$WATERMARK_SCALE_FACTOR"
  #write_file /proc/sys/vm/page-cluster 0
  #write_file /proc/sys/vm/compaction_proactiveness 0
  #write_file /proc/sys/vm/vfs_cache_pressure "$VFS_CACHE_PRESSURE"
}

state_file_for_pkg() {
  echo "$STATE_DIR/$(echo "$1" | sed 's/[^A-Za-z0-9_.-]/_/g').last_pid"
}

set_fifo_realtime() {
  local tid
  tid="$1"

  # Android Toybox takes "-p PID PRIORITY". Keep a BusyBox fallback for
  # devices whose ROM does not ship /system/bin/chrt.
  if [ -x /system/bin/chrt ]; then
    /system/bin/chrt -f -p "$tid" "$UNITY_RT_PRIORITY" >/dev/null 2>&1
  elif command -v toybox >/dev/null 2>&1; then
    toybox chrt -f -p "$tid" "$UNITY_RT_PRIORITY" >/dev/null 2>&1
  elif command -v busybox >/dev/null 2>&1; then
    busybox chrt -f -p "$UNITY_RT_PRIORITY" "$tid" >/dev/null 2>&1
  else
    return 127
  fi
}

set_uclamp_min() {
  local tid
  tid="$1"

  if [ -x /system/bin/uclampset ]; then
    /system/bin/uclampset -m "$UNITY_UCLAMP_MIN" -p "$tid" >/dev/null 2>&1 && return 0
  fi
  if [ -x /system/bin/toybox ]; then
    /system/bin/toybox uclampset -m "$UNITY_UCLAMP_MIN" -p "$tid" >/dev/null 2>&1 && return 0
  fi
  if command -v uclampset >/dev/null 2>&1; then
    uclampset -m "$UNITY_UCLAMP_MIN" -p "$tid" >/dev/null 2>&1 && return 0
  fi
  return 1
}

set_thread_nice() {
  local tid current_nice nice_increment
  tid="$1"
  current_nice="$2"
  nice_increment=$((UNITY_NICE - current_nice))
  [ "$nice_increment" -ne 0 ] || return 0

  # Android Toybox and BusyBox interpret -n as an increment, so calculate
  # the delta from the current value instead of repeatedly passing -20.
  if [ -x /system/bin/renice ]; then
    /system/bin/renice -n "$nice_increment" -p "$tid" >/dev/null 2>&1 && return 0
  fi
  if [ -x /system/bin/toybox ]; then
    /system/bin/toybox renice -n "$nice_increment" -p "$tid" >/dev/null 2>&1 && return 0
  fi
  if command -v busybox >/dev/null 2>&1; then
    busybox renice -n "$nice_increment" -p "$tid" >/dev/null 2>&1 && return 0
  fi
  return 1
}

is_thread_name_in_list() {
  local thread_name configured_names configured_name
  thread_name="$1"
  configured_names="$2"

  for configured_name in $configured_names; do
    [ "$thread_name" = "$configured_name" ] && return 0
  done
  return 1
}

tune_unity_threads() {
  local pkg main task_dir tid thread_name uclamp_min current_nice policy failure_marker
  pkg="$1"
  main="$(pidof "$pkg" 2>/dev/null | awk '{print $1}')"
  [ -n "$main" ] && [ -d "/proc/$main/task" ] || return 0

  for task_dir in "/proc/$main/task/"*; do
    [ -d "$task_dir" ] || continue
    tid="${task_dir##*/}"
    IFS= read -r thread_name < "$task_dir/comm" 2>/dev/null

    if is_thread_name_in_list "$thread_name" "$UCLAMP_THREAD_NAMES"; then
      uclamp_min="$(awk '$1=="uclamp.min"{print $3; exit}' "$task_dir/sched" 2>/dev/null)"
      if [ "$uclamp_min" != "$UNITY_UCLAMP_MIN" ]; then
        failure_marker="$STATE_DIR/uclamp_failed_${main}_${tid}"
        if set_uclamp_min "$tid"; then
          rm -f "$failure_marker" 2>/dev/null
          log "thread uclamp pkg=$pkg pid=$main tid=$tid name=$thread_name min=$UNITY_UCLAMP_MIN"
        elif [ -d "$task_dir" ] && [ ! -e "$failure_marker" ]; then
          log "thread uclamp failed pkg=$pkg pid=$main tid=$tid name=$thread_name min=$UNITY_UCLAMP_MIN"
          : > "$failure_marker"
        fi
      fi
    fi

    if is_thread_name_in_list "$thread_name" "$RENICE_THREAD_NAMES"; then
      current_nice="$(awk '{print $19; exit}' "$task_dir/stat" 2>/dev/null)"
      if [ -n "$current_nice" ] && [ "$current_nice" != "$UNITY_NICE" ]; then
        failure_marker="$STATE_DIR/renice_failed_${main}_${tid}"
        if set_thread_nice "$tid" "$current_nice"; then
          rm -f "$failure_marker" 2>/dev/null
          log "thread renice pkg=$pkg pid=$main tid=$tid name=$thread_name nice=$UNITY_NICE"
        elif [ -d "$task_dir" ] && [ ! -e "$failure_marker" ]; then
          log "thread renice failed pkg=$pkg pid=$main tid=$tid name=$thread_name nice=$UNITY_NICE"
          : > "$failure_marker"
        fi
      fi
    fi

    is_thread_name_in_list "$thread_name" "$RT_THREAD_NAMES" || continue

    # Policies 1 and 2 are SCHED_FIFO and SCHED_RR respectively. Avoid a
    # redundant syscall when the game has already made this thread realtime.
    policy="$(awk '$1=="policy"{print $3; exit}' "$task_dir/sched" 2>/dev/null)"
    if [ "$policy" = "1" ] || [ "$policy" = "2" ]; then
      continue
    fi

    failure_marker="$STATE_DIR/unity_rt_failed_${main}_${tid}"
    if set_fifo_realtime "$tid"; then
      rm -f "$failure_marker" 2>/dev/null
      log "thread realtime pkg=$pkg pid=$main tid=$tid name=$thread_name policy=SCHED_FIFO priority=$UNITY_RT_PRIORITY"
    elif [ -d "$task_dir" ] && [ ! -e "$failure_marker" ]; then
      log "thread realtime failed pkg=$pkg pid=$main tid=$tid name=$thread_name priority=$UNITY_RT_PRIORITY"
      : > "$failure_marker"
    fi
  done
}

move_uid_memcg_to_protect() {
  local pkg main uid uid_memcg p moved state_file last_main
  pkg="$1"
  main="$(pidof "$pkg" 2>/dev/null | awk '{print $1}')"
  [ -n "$main" ] && [ -d "/proc/$main" ] || return 0

  uid="$(pid_uid "$main")"
  [ -n "$uid" ] || return 0

  uid_memcg="/dev/memcg/mimd/uid_$uid"
  if [ ! -d "$uid_memcg" ]; then
    uid_memcg="$(pid_memcg "$main")"
  fi
  [ -d "$uid_memcg" ] || return 0

  echo "$GAME_SWAPPINESS" > "$uid_memcg/memory.swappiness" 2>/dev/null
  prepare_protect_memcg || return 0

  moved=0
  if [ -r "$uid_memcg/cgroup.procs" ]; then
    for p in $(cat "$uid_memcg/cgroup.procs" 2>/dev/null); do
      [ -d "/proc/$p" ] || continue
      echo "$p" > "$PROTECT_MEMCG/cgroup.procs" 2>/dev/null && moved=$((moved + 1))
    done
  fi

  echo "$main" > "$PROTECT_MEMCG/cgroup.procs" 2>/dev/null

  mkdir -p "$STATE_DIR" 2>/dev/null
  state_file="$(state_file_for_pkg "$pkg")"
  last_main="$(cat "$state_file" 2>/dev/null)"
  if [ "$main" != "$last_main" ]; then
    log "game detected pkg=$pkg pid=$main uid=$uid source_memcg=$uid_memcg moved_from_uid_memcg=$moved protect=$PROTECT_MEMCG"
    echo "$main" > "$state_file" 2>/dev/null
  fi
}

daemon_loop() {
  : > "$LOG"
  rm -rf "$STATE_DIR" 2>/dev/null
  mkdir -p "$STATE_DIR" 2>/dev/null
  log "daemon start low-overhead pkgs=$PKGS loop=${LOOP_SECONDS}s"
  sleep 45
  #apply_global_tuning

  while true; do
    for pkg in $PKGS; do
      move_uid_memcg_to_protect "$pkg"
      tune_unity_threads "$pkg"
    done
    sleep "$LOOP_SECONDS"
  done
}

old="$(cat "$PIDFILE" 2>/dev/null)"
if [ -n "$old" ] && [ -d "/proc/$old" ]; then
  kill "$old" 2>/dev/null
  sleep 1
  [ -d "/proc/$old" ] && kill -9 "$old" 2>/dev/null
fi

( daemon_loop ) >/dev/null 2>&1 &
echo "$!" > "$PIDFILE" 2>/dev/null
log "service spawned daemon pid=$!"
exit 0
